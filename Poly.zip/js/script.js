document.addEventListener('DOMContentLoaded', function() {
  console.log('Project Poly is ready!');
});